import SistemaEleicao.SistemaEleicao;

public class App {
    public static void main(String[] args) {
        SistemaEleicao.inicializarSistema();
        boolean executando = true;

        while (executando) {
            if (SistemaEleicao.getUsuarioLogado() == null) {
                SistemaEleicao.mostrarMenuInicial();
            } else {
                SistemaEleicao.mostrarMenuPrincipal();
            }
        }
    }
}
