package SistemaEleicao;

import java.util.*;
import Interfaces.*;
import Cliente.*;
import Gerenciamento.*;

public class SistemaEleicao {
    private static Scanner scanner = new Scanner(System.in);
    private static GerenciadorUsuarios gerenciadorUsuarios = new GerenciadorUsuarios();
    private static GerenciadorCandidatos gerenciadorCandidatos = new GerenciadorCandidatos();
    private static IUsuarios usuarioLogado = null;

    public static void inicializarSistema() {
        gerenciadorUsuarios.carregarUsuarios();
        gerenciadorCandidatos.carregarCandidatos();
    }

    public static void salvarDados() {
        gerenciadorUsuarios.salvarUsuarios();
        gerenciadorCandidatos.salvarCandidatos();
    }

    public static void mostrarMenuInicial() {
        System.out.println("1. Cadastro de login");
        System.out.println("2. Login");
        System.out.println("3. Sair");
        System.out.print("Escolha uma opção: ");
        int escolha = scanner.nextInt();
        scanner.nextLine();

        switch (escolha) {
            case 1:
                cadastrarLogin();
                break;
            case 2:
                login();
                break;
            case 3:
                salvarDados();
                System.exit(0);
            default:
                System.out.println("Opção inválida.");
        }
    }

    public static void mostrarMenuPrincipal() {
        System.out.println("1. Cadastrar candidatos");
        System.out.println("2. Votar");
        System.out.println("3. Visualizar resultado");
        System.out.println("4. Logout");
        System.out.print("Escolha uma opção: ");
        int escolha = scanner.nextInt();
        scanner.nextLine();

        switch (escolha) {
            case 1:
                cadastrarCandidatos();
                break;
            case 2:
                votar();
                break;
            case 3:
                visualizarResultado();
                break;
            case 4:
                usuarioLogado = null;
                break;
            default:
                System.out.println("Opção inválida.");
        }
    }

    public static void cadastrarLogin() {
        System.out.print("Digite o login: ");
        String login = scanner.nextLine();
        System.out.print("Digite a senha: ");
        String senha = scanner.nextLine();
        gerenciadorUsuarios.adicionarUsuario(new Usuarios(login, senha));
        System.out.println("Usuário cadastrado com sucesso.");
    }

    public static void login() {
        System.out.print("Digite o login: ");
        String login = scanner.nextLine();
        System.out.print("Digite a senha: ");
        String senha = scanner.nextLine();

        for (IUsuarios usuario : gerenciadorUsuarios.getUsuarios()) {
            if (usuario.getLogin().equals(login) && usuario.getSenha().equals(senha)) {
                usuarioLogado = usuario;
                System.out.println("Login realizado com sucesso.");
                return;
            }
        }

        System.out.println("Login ou senha inválidos.");
    }

    public static void cadastrarCandidatos() {
        System.out.print("Digite o nome do candidato: ");
        String nome = scanner.nextLine();
        gerenciadorCandidatos.adicionarCandidato(new Candidatos(nome));
        System.out.println("Candidato cadastrado com sucesso.");
    }

    public static void votar() {
        if (gerenciadorCandidatos.getCandidatos().isEmpty()) {
            System.out.println("Nenhum candidato cadastrado.");
            return;
        }

        System.out.println("Lista de candidatos:");
        for (int i = 0; i < gerenciadorCandidatos.getCandidatos().size(); i++) {
            System.out.println((i + 1) + ". " + gerenciadorCandidatos.getCandidatos().get(i).getNome());
        }

        System.out.print("Escolha o número do candidato para votar: ");
        int escolha = scanner.nextInt();
        scanner.nextLine();

        if (escolha < 1 || escolha > gerenciadorCandidatos.getCandidatos().size()) {
            System.out.println("Escolha inválida.");
        } else {
            gerenciadorCandidatos.getCandidatos().get(escolha - 1).votar();
            System.out.println("Voto registrado com sucesso.");
        }
    }

    public static void visualizarResultado() {
        if (gerenciadorCandidatos.getCandidatos().isEmpty()) {
            System.out.println("Nenhum candidato cadastrado.");
            return;
        }

        System.out.println("Resultado da eleição:");
        for (Candidatos candidato : gerenciadorCandidatos.getCandidatos()) {
            System.out.println(candidato.getNome() + ": " + candidato.getVotos() + " votos");
        }
    }

    public static Scanner getScanner() {
        return scanner;
    }

    public static void setScanner(Scanner scanner) {
        SistemaEleicao.scanner = scanner;
    }

    public static GerenciadorUsuarios getGerenciadorUsuarios() {
        return gerenciadorUsuarios;
    }

    public static void setGerenciadorUsuarios(GerenciadorUsuarios gerenciadorUsuarios) {
        SistemaEleicao.gerenciadorUsuarios = gerenciadorUsuarios;
    }

    public static GerenciadorCandidatos getGerenciadorCandidatos() {
        return gerenciadorCandidatos;
    }

    public static void setGerenciadorCandidatos(GerenciadorCandidatos gerenciadorCandidatos) {
        SistemaEleicao.gerenciadorCandidatos = gerenciadorCandidatos;
    }

    public static IUsuarios getUsuarioLogado() {
        return usuarioLogado;
    }

    public static void setUsuarioLogado(IUsuarios usuarioLogado) {
        SistemaEleicao.usuarioLogado = usuarioLogado;
    }
}
