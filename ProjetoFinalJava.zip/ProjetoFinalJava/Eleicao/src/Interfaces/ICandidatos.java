package Interfaces;

public interface ICandidatos {
    String getNome();

    int getVotos();

    void votar();
}
