package Interfaces;

public interface IUsuarios {
    String getLogin();
    String getSenha();
}

