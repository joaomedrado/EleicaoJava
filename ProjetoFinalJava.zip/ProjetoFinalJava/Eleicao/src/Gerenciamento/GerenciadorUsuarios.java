package Gerenciamento;

import java.io.*;
import java.util.*;
import Cliente.Usuarios;
import Interfaces.IUsuarios;

public class GerenciadorUsuarios {
    private static final String ARQUIVO_USUARIOS = "usuarios.txt";
    private List<IUsuarios> usuarios = new ArrayList<>();

    public void carregarUsuarios() {
        try (BufferedReader reader = new BufferedReader(new FileReader(ARQUIVO_USUARIOS))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                String[] dados = linha.split(",");
                if (dados.length == 2) {
                    usuarios.add(new Usuarios(dados[0], dados[1]));
                }
            }
        } catch (IOException e) {
            System.out.println("Erro ao carregar usuários: " + e.getMessage());
        }
    }

    public void salvarUsuarios() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ARQUIVO_USUARIOS))) {
            for (IUsuarios usuario : usuarios) {
                writer.write(usuario.getLogin() + "," + usuario.getSenha());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Erro ao salvar usuários: " + e.getMessage());
        }
    }

    public List<IUsuarios> getUsuarios() {
        return usuarios;
    }

    public void adicionarUsuario(IUsuarios usuario) {
        usuarios.add(usuario);
    }
}

