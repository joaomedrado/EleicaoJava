package Gerenciamento;

import java.io.*;
import java.util.*;

import Cliente.Candidatos;
import Interfaces.ICandidatos;

public class GerenciadorCandidatos {
    private static final String ARQUIVO_CANDIDATOS = "candidatos.txt";
    private List<Candidatos> candidatos = new ArrayList<>();

    public void carregarCandidatos() {
        try (BufferedReader reader = new BufferedReader(new FileReader(ARQUIVO_CANDIDATOS))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                String[] dados = linha.split(",");
                if (dados.length == 2) {
                    Candidatos candidato = new Candidatos(dados[0]);
                    candidato.setVotos(Integer.parseInt(dados[1]));
                    candidatos.add(candidato);
                }
            }
        } catch (IOException e) {
            System.out.println("Erro ao carregar candidatos: " + e.getMessage());
        }
    }

    public void salvarCandidatos() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ARQUIVO_CANDIDATOS))) {
            for (Candidatos candidato : candidatos) {
                writer.write(candidato.getNome() + "," + candidato.getVotos());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Erro ao salvar candidatos: " + e.getMessage());
        }
    }

    public List<Candidatos> getCandidatos() {
        return candidatos;
    }

    public void adicionarCandidato(Candidatos candidato) {
        candidatos.add(candidato);
    }
}
