package Cliente;
import Interfaces.ICandidatos;


public class Candidatos implements ICandidatos {

    private String nome;
    private int votos;

    public Candidatos(String nome) {
        this.nome = nome;
        this.votos = 0;
    }

    public String getNome() {
        return nome;
    }

    public int getVotos() {
        return votos;
    }

    public void votar() {
        this.votos++;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setVotos(int votos) {
        this.votos = votos;
    }

    
}
